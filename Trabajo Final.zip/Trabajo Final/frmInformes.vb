﻿Public Class frmInformes
    Private Sub frmInformes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dateTimeFecha.CustomFormat = "dd/MM/yyyy"
        dateTimeFecha.Visible = False
        txtAux.Visible = False
        txtCodigoAux.Visible = False
        btnObservacion.Enabled = False
        leerArticulosCombo(comboBoxArticulo)
    End Sub

    Private Sub comboBoxArticulo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBoxArticulo.SelectedIndexChanged
        listInformes.Items.Clear()
        btnObservacion.Enabled = False
        leerInformes(comboBoxArticulo.Text, dateTimeFecha, listInformes)
    End Sub

    Private Sub listInformes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listInformes.SelectedIndexChanged
        Dim codigo As String

        txtAux.Text = listInformes.SelectedItem
        codigo = Mid(txtAux.Text, Len(txtAux.Text) - 2, 3)
        txtCodigoAux.Text = codigo
        btnObservacion.Enabled = True
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Sub limpiar()
        comboBoxArticulo.SelectedIndex = 0
        listInformes.Items.Clear()
    End Sub

    Private Sub btnObservacion_Click(sender As Object, e As EventArgs) Handles btnObservacion.Click
        leerObservacion(txtCodigoAux.Text)
        frmObservacion.ShowDialog()
    End Sub


End Class