﻿Public Class frmBusquedaAgrupaciones

    Private Sub frmBusqueda_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        listAgrupaciones.Items.Clear()
        leerAgrupacionesList(listAgrupaciones)
        leerAgrupacionesList(listAux)
        txtAux.Visible = False
    End Sub

    Private Sub listAgrupaciones_DoubleClick(sender As Object, e As EventArgs) Handles listAgrupaciones.DoubleClick
        pasar()
    End Sub

    Sub pasar()
        Dim codigo As String
        Dim agrupacion As String

        txtAux.Text = listAgrupaciones.SelectedItem
        codigo = Mid(txtAux.Text, 1, 3)
        agrupacion = Mid(txtAux.Text, 5, Len(txtAux.Text) - 1)
        'MsgBox("Codigo = " & codigo & " Agrupacion = " & agrupacion)
        frmAgrupaciones.txtCodigo.Text = codigo
        frmAgrupaciones.txtNombre.Text = agrupacion
        agrupacion = Mid(frmAgrupaciones.txtNombre.Text, 2, Len(frmAgrupaciones.txtNombre.Text))
        agrupacion = LCase(agrupacion)
        frmAgrupaciones.txtNombre.Text = Mid(frmAgrupaciones.txtNombre.Text, 1, 1)
        frmAgrupaciones.txtNombre.Text = frmAgrupaciones.txtNombre.Text + agrupacion
        frmAgrupaciones.btnAgregar.Enabled = False
        frmAgrupaciones.btnModificar.Enabled = True
        frmAgrupaciones.btnEliminar.Enabled = True
        Me.Close()
    End Sub

    Private Sub txtBusqueda_TextChanged(sender As Object, e As EventArgs) Handles txtBusqueda.TextChanged
        buscarElemento(txtBusqueda)
    End Sub

    Sub buscarElemento(txtBusqueda As TextBox)

        Dim I As Integer

        listAgrupaciones.Items.Clear()

        For I = 0 To listAux.Items.Count - 1
            Select Case listAux.Items(I).IndexOf(UCase(txtBusqueda.Text))
                Case <> -1
                    listAgrupaciones.Items.Add(listAux.Items(I))
            End Select
        Next

    End Sub

End Class