﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusquedaMovimientos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBusquedaMovimientos))
        Me.listMovimientos = New System.Windows.Forms.ListBox()
        Me.txtAux = New System.Windows.Forms.TextBox()
        Me.listAux = New System.Windows.Forms.ListBox()
        Me.txtBusqueda = New System.Windows.Forms.TextBox()
        Me.lblTipo = New System.Windows.Forms.Label()
        Me.lblCodigo = New System.Windows.Forms.Label()
        Me.lblMovimiento = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'listMovimientos
        '
        Me.listMovimientos.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listMovimientos.Font = New System.Drawing.Font("Courier New", 15.0!)
        Me.listMovimientos.FormattingEnabled = True
        Me.listMovimientos.ItemHeight = 22
        Me.listMovimientos.Location = New System.Drawing.Point(20, 91)
        Me.listMovimientos.Name = "listMovimientos"
        Me.listMovimientos.Size = New System.Drawing.Size(275, 136)
        Me.listMovimientos.TabIndex = 4
        '
        'txtAux
        '
        Me.txtAux.Location = New System.Drawing.Point(221, 197)
        Me.txtAux.Name = "txtAux"
        Me.txtAux.Size = New System.Drawing.Size(64, 20)
        Me.txtAux.TabIndex = 5
        '
        'listAux
        '
        Me.listAux.Font = New System.Drawing.Font("Courier New", 9.75!)
        Me.listAux.FormattingEnabled = True
        Me.listAux.ItemHeight = 16
        Me.listAux.Location = New System.Drawing.Point(341, 95)
        Me.listAux.Name = "listAux"
        Me.listAux.Size = New System.Drawing.Size(336, 148)
        Me.listAux.TabIndex = 6
        '
        'txtBusqueda
        '
        Me.txtBusqueda.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtBusqueda.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.txtBusqueda.Location = New System.Drawing.Point(64, 29)
        Me.txtBusqueda.Name = "txtBusqueda"
        Me.txtBusqueda.Size = New System.Drawing.Size(192, 25)
        Me.txtBusqueda.TabIndex = 7
        '
        'lblTipo
        '
        Me.lblTipo.AutoSize = True
        Me.lblTipo.BackColor = System.Drawing.Color.Transparent
        Me.lblTipo.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblTipo.Location = New System.Drawing.Point(252, 74)
        Me.lblTipo.Name = "lblTipo"
        Me.lblTipo.Size = New System.Drawing.Size(33, 14)
        Me.lblTipo.TabIndex = 18
        Me.lblTipo.Text = "Tipo"
        '
        'lblCodigo
        '
        Me.lblCodigo.AutoSize = True
        Me.lblCodigo.BackColor = System.Drawing.Color.Transparent
        Me.lblCodigo.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblCodigo.Location = New System.Drawing.Point(17, 74)
        Me.lblCodigo.Name = "lblCodigo"
        Me.lblCodigo.Size = New System.Drawing.Size(51, 14)
        Me.lblCodigo.TabIndex = 17
        Me.lblCodigo.Text = "Código"
        '
        'lblMovimiento
        '
        Me.lblMovimiento.AutoSize = True
        Me.lblMovimiento.BackColor = System.Drawing.Color.Transparent
        Me.lblMovimiento.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblMovimiento.Location = New System.Drawing.Point(71, 74)
        Me.lblMovimiento.Name = "lblMovimiento"
        Me.lblMovimiento.Size = New System.Drawing.Size(78, 14)
        Me.lblMovimiento.TabIndex = 19
        Me.lblMovimiento.Text = "Movimiento"
        '
        'frmBusquedaMovimientos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(316, 239)
        Me.Controls.Add(Me.lblMovimiento)
        Me.Controls.Add(Me.lblTipo)
        Me.Controls.Add(Me.lblCodigo)
        Me.Controls.Add(Me.txtBusqueda)
        Me.Controls.Add(Me.listAux)
        Me.Controls.Add(Me.txtAux)
        Me.Controls.Add(Me.listMovimientos)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(332, 278)
        Me.MinimumSize = New System.Drawing.Size(332, 278)
        Me.Name = "frmBusquedaMovimientos"
        Me.Text = "Búsqueda Movimientos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents listMovimientos As ListBox
    Friend WithEvents txtAux As TextBox
    Friend WithEvents listAux As ListBox
    Friend WithEvents txtBusqueda As TextBox
    Friend WithEvents lblTipo As Label
    Friend WithEvents lblCodigo As Label
    Friend WithEvents lblMovimiento As Label
End Class
