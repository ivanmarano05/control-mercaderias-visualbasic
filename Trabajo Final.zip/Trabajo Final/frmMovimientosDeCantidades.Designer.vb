﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMovimientosDeCantidades
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMovimientosDeCantidades))
        Me.comboBoxMovimientos = New System.Windows.Forms.ComboBox()
        Me.lblTipo = New System.Windows.Forms.Label()
        Me.lblArticulo = New System.Windows.Forms.Label()
        Me.txtCantidad = New System.Windows.Forms.TextBox()
        Me.lblCantidad = New System.Windows.Forms.Label()
        Me.txtObservacion = New System.Windows.Forms.TextBox()
        Me.lblObservacion = New System.Windows.Forms.Label()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.btnAgregar = New System.Windows.Forms.Button()
        Me.comboBoxArticulo = New System.Windows.Forms.ComboBox()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.dateTimeFecha = New System.Windows.Forms.DateTimePicker()
        Me.lblFecha = New System.Windows.Forms.Label()
        Me.txtCodigoTipoAux = New System.Windows.Forms.TextBox()
        Me.txtTipoAux = New System.Windows.Forms.TextBox()
        Me.txtCodigoArticuloAux = New System.Windows.Forms.TextBox()
        Me.txtArticuloAux = New System.Windows.Forms.TextBox()
        Me.txtTipoTipoAux = New System.Windows.Forms.TextBox()
        Me.txtPrecioArticuloAux = New System.Windows.Forms.TextBox()
        Me.lblSignoPesos = New System.Windows.Forms.Label()
        Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'comboBoxMovimientos
        '
        Me.comboBoxMovimientos.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.comboBoxMovimientos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxMovimientos.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.comboBoxMovimientos.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.comboBoxMovimientos.FormattingEnabled = True
        Me.comboBoxMovimientos.Location = New System.Drawing.Point(241, 33)
        Me.comboBoxMovimientos.MaxDropDownItems = 2
        Me.comboBoxMovimientos.Name = "comboBoxMovimientos"
        Me.comboBoxMovimientos.Size = New System.Drawing.Size(209, 28)
        Me.comboBoxMovimientos.TabIndex = 21
        '
        'lblTipo
        '
        Me.lblTipo.AutoSize = True
        Me.lblTipo.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblTipo.Location = New System.Drawing.Point(171, 33)
        Me.lblTipo.Name = "lblTipo"
        Me.lblTipo.Size = New System.Drawing.Size(63, 25)
        Me.lblTipo.TabIndex = 19
        Me.lblTipo.Text = "Tipo:"
        '
        'lblArticulo
        '
        Me.lblArticulo.AutoSize = True
        Me.lblArticulo.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblArticulo.Location = New System.Drawing.Point(135, 71)
        Me.lblArticulo.Name = "lblArticulo"
        Me.lblArticulo.Size = New System.Drawing.Size(99, 25)
        Me.lblArticulo.TabIndex = 18
        Me.lblArticulo.Text = "Artículo:"
        '
        'txtCantidad
        '
        Me.txtCantidad.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCantidad.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtCantidad.Location = New System.Drawing.Point(240, 140)
        Me.txtCantidad.Name = "txtCantidad"
        Me.txtCantidad.Size = New System.Drawing.Size(68, 29)
        Me.txtCantidad.TabIndex = 23
        '
        'lblCantidad
        '
        Me.lblCantidad.AutoSize = True
        Me.lblCantidad.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblCantidad.Location = New System.Drawing.Point(124, 144)
        Me.lblCantidad.Name = "lblCantidad"
        Me.lblCantidad.Size = New System.Drawing.Size(110, 25)
        Me.lblCantidad.TabIndex = 22
        Me.lblCantidad.Text = "Cantidad:"
        '
        'txtObservacion
        '
        Me.txtObservacion.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtObservacion.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtObservacion.Location = New System.Drawing.Point(240, 175)
        Me.txtObservacion.Multiline = True
        Me.txtObservacion.Name = "txtObservacion"
        Me.txtObservacion.Size = New System.Drawing.Size(264, 75)
        Me.txtObservacion.TabIndex = 25
        '
        'lblObservacion
        '
        Me.lblObservacion.AutoSize = True
        Me.lblObservacion.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblObservacion.Location = New System.Drawing.Point(89, 175)
        Me.lblObservacion.Name = "lblObservacion"
        Me.lblObservacion.Size = New System.Drawing.Size(145, 25)
        Me.lblObservacion.TabIndex = 24
        Me.lblObservacion.Text = "Observación:"
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLimpiar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLimpiar.Image = CType(resources.GetObject("btnLimpiar.Image"), System.Drawing.Image)
        Me.btnLimpiar.Location = New System.Drawing.Point(240, 272)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(75, 50)
        Me.btnLimpiar.TabIndex = 27
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'btnAgregar
        '
        Me.btnAgregar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAgregar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAgregar.Image = CType(resources.GetObject("btnAgregar.Image"), System.Drawing.Image)
        Me.btnAgregar.Location = New System.Drawing.Point(322, 272)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(75, 50)
        Me.btnAgregar.TabIndex = 26
        Me.btnAgregar.UseVisualStyleBackColor = False
        '
        'comboBoxArticulo
        '
        Me.comboBoxArticulo.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.comboBoxArticulo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxArticulo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.comboBoxArticulo.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.comboBoxArticulo.FormattingEnabled = True
        Me.comboBoxArticulo.Location = New System.Drawing.Point(241, 70)
        Me.comboBoxArticulo.MaxDropDownItems = 2
        Me.comboBoxArticulo.Name = "comboBoxArticulo"
        Me.comboBoxArticulo.Size = New System.Drawing.Size(209, 28)
        Me.comboBoxArticulo.TabIndex = 28
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBuscar.Image = CType(resources.GetObject("btnBuscar.Image"), System.Drawing.Image)
        Me.btnBuscar.Location = New System.Drawing.Point(403, 272)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(75, 50)
        Me.btnBuscar.TabIndex = 29
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'dateTimeFecha
        '
        Me.dateTimeFecha.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.CalendarTitleBackColor = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.CalendarTitleForeColor = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.CalendarTrailingForeColor = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.dateTimeFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateTimeFecha.Location = New System.Drawing.Point(241, 106)
        Me.dateTimeFecha.Name = "dateTimeFecha"
        Me.dateTimeFecha.Size = New System.Drawing.Size(148, 29)
        Me.dateTimeFecha.TabIndex = 30
        Me.dateTimeFecha.Value = New Date(2022, 11, 4, 2, 36, 0, 0)
        '
        'lblFecha
        '
        Me.lblFecha.AutoSize = True
        Me.lblFecha.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblFecha.Location = New System.Drawing.Point(154, 108)
        Me.lblFecha.Name = "lblFecha"
        Me.lblFecha.Size = New System.Drawing.Size(80, 25)
        Me.lblFecha.TabIndex = 31
        Me.lblFecha.Text = "Fecha:"
        '
        'txtCodigoTipoAux
        '
        Me.txtCodigoTipoAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCodigoTipoAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtCodigoTipoAux.Location = New System.Drawing.Point(39, 23)
        Me.txtCodigoTipoAux.Name = "txtCodigoTipoAux"
        Me.txtCodigoTipoAux.Size = New System.Drawing.Size(44, 29)
        Me.txtCodigoTipoAux.TabIndex = 33
        '
        'txtTipoAux
        '
        Me.txtTipoAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtTipoAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtTipoAux.Location = New System.Drawing.Point(12, 58)
        Me.txtTipoAux.Name = "txtTipoAux"
        Me.txtTipoAux.Size = New System.Drawing.Size(100, 29)
        Me.txtTipoAux.TabIndex = 32
        '
        'txtCodigoArticuloAux
        '
        Me.txtCodigoArticuloAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCodigoArticuloAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtCodigoArticuloAux.Location = New System.Drawing.Point(583, 3)
        Me.txtCodigoArticuloAux.Name = "txtCodigoArticuloAux"
        Me.txtCodigoArticuloAux.Size = New System.Drawing.Size(44, 29)
        Me.txtCodigoArticuloAux.TabIndex = 35
        '
        'txtArticuloAux
        '
        Me.txtArticuloAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtArticuloAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtArticuloAux.Location = New System.Drawing.Point(554, 35)
        Me.txtArticuloAux.Name = "txtArticuloAux"
        Me.txtArticuloAux.Size = New System.Drawing.Size(100, 29)
        Me.txtArticuloAux.TabIndex = 34
        '
        'txtTipoTipoAux
        '
        Me.txtTipoTipoAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtTipoTipoAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtTipoTipoAux.Location = New System.Drawing.Point(39, 97)
        Me.txtTipoTipoAux.Name = "txtTipoTipoAux"
        Me.txtTipoTipoAux.Size = New System.Drawing.Size(44, 29)
        Me.txtTipoTipoAux.TabIndex = 36
        '
        'txtPrecioArticuloAux
        '
        Me.txtPrecioArticuloAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtPrecioArticuloAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtPrecioArticuloAux.Location = New System.Drawing.Point(482, 71)
        Me.txtPrecioArticuloAux.Name = "txtPrecioArticuloAux"
        Me.txtPrecioArticuloAux.ReadOnly = True
        Me.txtPrecioArticuloAux.Size = New System.Drawing.Size(111, 29)
        Me.txtPrecioArticuloAux.TabIndex = 37
        '
        'lblSignoPesos
        '
        Me.lblSignoPesos.AutoSize = True
        Me.lblSignoPesos.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.lblSignoPesos.Location = New System.Drawing.Point(459, 74)
        Me.lblSignoPesos.Name = "lblSignoPesos"
        Me.lblSignoPesos.Size = New System.Drawing.Size(21, 22)
        Me.lblSignoPesos.TabIndex = 38
        Me.lblSignoPesos.Text = "$"
        '
        'frmMovimientosDeCantidades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(666, 354)
        Me.Controls.Add(Me.lblSignoPesos)
        Me.Controls.Add(Me.txtPrecioArticuloAux)
        Me.Controls.Add(Me.txtTipoTipoAux)
        Me.Controls.Add(Me.txtCodigoArticuloAux)
        Me.Controls.Add(Me.txtArticuloAux)
        Me.Controls.Add(Me.txtCodigoTipoAux)
        Me.Controls.Add(Me.txtTipoAux)
        Me.Controls.Add(Me.lblFecha)
        Me.Controls.Add(Me.dateTimeFecha)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.comboBoxArticulo)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnAgregar)
        Me.Controls.Add(Me.txtObservacion)
        Me.Controls.Add(Me.lblObservacion)
        Me.Controls.Add(Me.txtCantidad)
        Me.Controls.Add(Me.lblCantidad)
        Me.Controls.Add(Me.comboBoxMovimientos)
        Me.Controls.Add(Me.lblTipo)
        Me.Controls.Add(Me.lblArticulo)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(682, 393)
        Me.MinimumSize = New System.Drawing.Size(682, 393)
        Me.Name = "frmMovimientosDeCantidades"
        Me.Text = "Movimientos De Cantidades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents comboBoxMovimientos As ComboBox
    Friend WithEvents lblTipo As Label
    Friend WithEvents lblArticulo As Label
    Friend WithEvents txtCantidad As TextBox
    Friend WithEvents lblCantidad As Label
    Friend WithEvents txtObservacion As TextBox
    Friend WithEvents lblObservacion As Label
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents comboBoxArticulo As ComboBox
    Friend WithEvents btnBuscar As Button
    Friend WithEvents dateTimeFecha As DateTimePicker
    Friend WithEvents lblFecha As Label
    Friend WithEvents txtCodigoTipoAux As TextBox
    Friend WithEvents txtTipoAux As TextBox
    Friend WithEvents txtCodigoArticuloAux As TextBox
    Friend WithEvents txtArticuloAux As TextBox
    Friend WithEvents txtTipoTipoAux As TextBox
    Friend WithEvents txtPrecioArticuloAux As TextBox
    Friend WithEvents lblSignoPesos As Label
    Friend WithEvents toolTip1 As ToolTip
End Class
