﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPrincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPrincipal))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AltasYActualizacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AgrupacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArtículosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TiposDeMovimientosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MovimientosDeCantidadesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblAltasYActualizaciones = New System.Windows.Forms.Label()
        Me.btnAgrupaciones = New System.Windows.Forms.Button()
        Me.btnArticulos = New System.Windows.Forms.Button()
        Me.btnTipo = New System.Windows.Forms.Button()
        Me.btnMovimientos = New System.Windows.Forms.Button()
        Me.lblMovimientosDeCantidades = New System.Windows.Forms.Label()
        Me.lblAgrupaciones = New System.Windows.Forms.Label()
        Me.lblArticulos = New System.Windows.Forms.Label()
        Me.lblTipo = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AltasYActualizacionesToolStripMenuItem, Me.MovimientosDeCantidadesToolStripMenuItem, Me.InformesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(784, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AltasYActualizacionesToolStripMenuItem
        '
        Me.AltasYActualizacionesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AgrupacionesToolStripMenuItem, Me.ArtículosToolStripMenuItem, Me.TiposDeMovimientosToolStripMenuItem})
        Me.AltasYActualizacionesToolStripMenuItem.Name = "AltasYActualizacionesToolStripMenuItem"
        Me.AltasYActualizacionesToolStripMenuItem.Size = New System.Drawing.Size(139, 20)
        Me.AltasYActualizacionesToolStripMenuItem.Text = "Altas y Actualizaciones"
        '
        'AgrupacionesToolStripMenuItem
        '
        Me.AgrupacionesToolStripMenuItem.Image = CType(resources.GetObject("AgrupacionesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AgrupacionesToolStripMenuItem.Name = "AgrupacionesToolStripMenuItem"
        Me.AgrupacionesToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.AgrupacionesToolStripMenuItem.Text = "Agrupaciones"
        '
        'ArtículosToolStripMenuItem
        '
        Me.ArtículosToolStripMenuItem.Image = CType(resources.GetObject("ArtículosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ArtículosToolStripMenuItem.Name = "ArtículosToolStripMenuItem"
        Me.ArtículosToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.ArtículosToolStripMenuItem.Text = "Artículos"
        '
        'TiposDeMovimientosToolStripMenuItem
        '
        Me.TiposDeMovimientosToolStripMenuItem.Image = CType(resources.GetObject("TiposDeMovimientosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TiposDeMovimientosToolStripMenuItem.Name = "TiposDeMovimientosToolStripMenuItem"
        Me.TiposDeMovimientosToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.TiposDeMovimientosToolStripMenuItem.Text = "Tipos de Movimientos"
        '
        'MovimientosDeCantidadesToolStripMenuItem
        '
        Me.MovimientosDeCantidadesToolStripMenuItem.Name = "MovimientosDeCantidadesToolStripMenuItem"
        Me.MovimientosDeCantidadesToolStripMenuItem.Size = New System.Drawing.Size(167, 20)
        Me.MovimientosDeCantidadesToolStripMenuItem.Text = "Movimientos de Cantidades"
        '
        'InformesToolStripMenuItem
        '
        Me.InformesToolStripMenuItem.Name = "InformesToolStripMenuItem"
        Me.InformesToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.InformesToolStripMenuItem.Text = "Informes"
        '
        'lblAltasYActualizaciones
        '
        Me.lblAltasYActualizaciones.AutoSize = True
        Me.lblAltasYActualizaciones.Font = New System.Drawing.Font("Verdana", 22.0!)
        Me.lblAltasYActualizaciones.Location = New System.Drawing.Point(164, 39)
        Me.lblAltasYActualizaciones.Name = "lblAltasYActualizaciones"
        Me.lblAltasYActualizaciones.Size = New System.Drawing.Size(444, 36)
        Me.lblAltasYActualizaciones.TabIndex = 1
        Me.lblAltasYActualizaciones.Text = "ALTAS Y ACTUALIZACIONES"
        '
        'btnAgrupaciones
        '
        Me.btnAgrupaciones.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAgrupaciones.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAgrupaciones.Image = CType(resources.GetObject("btnAgrupaciones.Image"), System.Drawing.Image)
        Me.btnAgrupaciones.Location = New System.Drawing.Point(60, 132)
        Me.btnAgrupaciones.Name = "btnAgrupaciones"
        Me.btnAgrupaciones.Size = New System.Drawing.Size(137, 100)
        Me.btnAgrupaciones.TabIndex = 2
        Me.btnAgrupaciones.UseVisualStyleBackColor = False
        '
        'btnArticulos
        '
        Me.btnArticulos.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnArticulos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnArticulos.Image = CType(resources.GetObject("btnArticulos.Image"), System.Drawing.Image)
        Me.btnArticulos.Location = New System.Drawing.Point(322, 132)
        Me.btnArticulos.Name = "btnArticulos"
        Me.btnArticulos.Size = New System.Drawing.Size(137, 100)
        Me.btnArticulos.TabIndex = 3
        Me.btnArticulos.UseVisualStyleBackColor = False
        '
        'btnTipo
        '
        Me.btnTipo.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTipo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTipo.Image = CType(resources.GetObject("btnTipo.Image"), System.Drawing.Image)
        Me.btnTipo.Location = New System.Drawing.Point(588, 132)
        Me.btnTipo.Name = "btnTipo"
        Me.btnTipo.Size = New System.Drawing.Size(137, 100)
        Me.btnTipo.TabIndex = 4
        Me.btnTipo.UseVisualStyleBackColor = False
        '
        'btnMovimientos
        '
        Me.btnMovimientos.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMovimientos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMovimientos.Image = CType(resources.GetObject("btnMovimientos.Image"), System.Drawing.Image)
        Me.btnMovimientos.Location = New System.Drawing.Point(146, 321)
        Me.btnMovimientos.Name = "btnMovimientos"
        Me.btnMovimientos.Size = New System.Drawing.Size(136, 100)
        Me.btnMovimientos.TabIndex = 5
        Me.btnMovimientos.UseVisualStyleBackColor = False
        '
        'lblMovimientosDeCantidades
        '
        Me.lblMovimientosDeCantidades.AutoSize = True
        Me.lblMovimientosDeCantidades.Font = New System.Drawing.Font("Verdana", 18.0!)
        Me.lblMovimientosDeCantidades.Location = New System.Drawing.Point(22, 267)
        Me.lblMovimientosDeCantidades.Name = "lblMovimientosDeCantidades"
        Me.lblMovimientosDeCantidades.Size = New System.Drawing.Size(401, 29)
        Me.lblMovimientosDeCantidades.TabIndex = 6
        Me.lblMovimientosDeCantidades.Text = "MOVIMIENTOS DE CANTIDADES"
        '
        'lblAgrupaciones
        '
        Me.lblAgrupaciones.AutoSize = True
        Me.lblAgrupaciones.Font = New System.Drawing.Font("Verdana", 16.0!)
        Me.lblAgrupaciones.Location = New System.Drawing.Point(48, 93)
        Me.lblAgrupaciones.Name = "lblAgrupaciones"
        Me.lblAgrupaciones.Size = New System.Drawing.Size(159, 26)
        Me.lblAgrupaciones.TabIndex = 7
        Me.lblAgrupaciones.Text = "Agrupaciones"
        '
        'lblArticulos
        '
        Me.lblArticulos.AutoSize = True
        Me.lblArticulos.Font = New System.Drawing.Font("Verdana", 16.0!)
        Me.lblArticulos.Location = New System.Drawing.Point(338, 93)
        Me.lblArticulos.Name = "lblArticulos"
        Me.lblArticulos.Size = New System.Drawing.Size(106, 26)
        Me.lblArticulos.TabIndex = 8
        Me.lblArticulos.Text = "Artículos"
        '
        'lblTipo
        '
        Me.lblTipo.AutoSize = True
        Me.lblTipo.Font = New System.Drawing.Font("Verdana", 16.0!)
        Me.lblTipo.Location = New System.Drawing.Point(531, 93)
        Me.lblTipo.Name = "lblTipo"
        Me.lblTipo.Size = New System.Drawing.Size(251, 26)
        Me.lblTipo.TabIndex = 9
        Me.lblTipo.Text = "Tipos de Movimientos"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 20.0!)
        Me.Label2.Location = New System.Drawing.Point(518, 264)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(160, 32)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "INFORMES"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(529, 321)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(136, 100)
        Me.Button1.TabIndex = 13
        Me.Button1.UseVisualStyleBackColor = False
        '
        'frmPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(784, 461)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblTipo)
        Me.Controls.Add(Me.lblArticulos)
        Me.Controls.Add(Me.lblAgrupaciones)
        Me.Controls.Add(Me.lblMovimientosDeCantidades)
        Me.Controls.Add(Me.btnMovimientos)
        Me.Controls.Add(Me.btnTipo)
        Me.Controls.Add(Me.btnArticulos)
        Me.Controls.Add(Me.btnAgrupaciones)
        Me.Controls.Add(Me.lblAltasYActualizaciones)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(800, 500)
        Me.MinimumSize = New System.Drawing.Size(800, 500)
        Me.Name = "frmPrincipal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menú Principal"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AltasYActualizacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AgrupacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ArtículosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TiposDeMovimientosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MovimientosDeCantidadesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InformesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblAltasYActualizaciones As Label
    Friend WithEvents btnAgrupaciones As Button
    Friend WithEvents btnArticulos As Button
    Friend WithEvents btnTipo As Button
    Friend WithEvents btnMovimientos As Button
    Friend WithEvents lblMovimientosDeCantidades As Label
    Friend WithEvents lblAgrupaciones As Label
    Friend WithEvents lblArticulos As Label
    Friend WithEvents lblTipo As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
End Class
