﻿Public Class frmBusquedaMovimientos
    Private Sub frmBusquedaMovimientos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        listMovimientos.Items.Clear()
        leerMovimientos(listMovimientos)
        leerMovimientos(listAux)
        txtAux.Visible = False
    End Sub

    Private Sub listMovimientos_DoubleClick(sender As Object, e As EventArgs) Handles listMovimientos.DoubleClick
        pasar()
    End Sub

    Sub pasar()
        Dim codigo As String
        Dim movimiento As String
        Dim tipo As String

        txtAux.Text = listMovimientos.SelectedItem
        codigo = Mid(txtAux.Text, 1, 3)
        movimiento = Mid(txtAux.Text, 5, 15)
        tipo = Mid(txtAux.Text, Len(txtAux.Text), Len(txtAux.Text))
        frmMovimientos.txtCodigo.Text = codigo
        movimiento = sacarEspacios(movimiento)
        frmMovimientos.txtNombre.Text = movimiento
        movimiento = Mid(frmMovimientos.txtNombre.Text, 2, Len(frmMovimientos.txtNombre.Text))
        movimiento = LCase(movimiento)
        frmMovimientos.txtNombre.Text = Mid(frmMovimientos.txtNombre.Text, 1, 1)
        frmMovimientos.txtNombre.Text = frmMovimientos.txtNombre.Text + movimiento
        frmMovimientos.comboBoxTipo.Text = tipo
        'MsgBox("Codigo = /" & codigo & " Movimiento = /" & movimiento & " Tipo = /" & tipo)
        frmMovimientos.btnAgregar.Enabled = False
        frmMovimientos.btnModificar.Enabled = True
        frmMovimientos.btnEliminar.Enabled = True
        Me.Close()
    End Sub

    Public Function sacarEspacios(movimiento As String)

        'Esta función elimina los espacios que se obtienen del listBox para trabajarlos limpios

        Dim I As Integer

        For I = 1 To Len(movimiento)
            If movimiento(Len(movimiento) - 1) = " " Then
                movimiento = movimiento.Remove(Len(movimiento) - 1, 1)
                'Console.WriteLine(movimiento & ".")
            End If
        Next

        Return movimiento

    End Function

    Private Sub txtBusqueda_TextChanged(sender As Object, e As EventArgs) Handles txtBusqueda.TextChanged
        buscarElemento(txtBusqueda)
    End Sub

    Sub buscarElemento(txtBusqueda As TextBox)

        Dim I As Integer

        listMovimientos.Items.Clear()

        For I = 0 To listAux.Items.Count - 1
            Select Case listAux.Items(I).IndexOf(UCase(txtBusqueda.Text))
                Case <> -1
                    listMovimientos.Items.Add(listAux.Items(I))
            End Select
        Next

    End Sub
End Class