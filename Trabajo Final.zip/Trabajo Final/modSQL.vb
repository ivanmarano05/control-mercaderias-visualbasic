﻿Imports System.Data.SqlClient

Module modSQL
    Public DaoCon As SqlConnection
    Public DaoCon2 As SqlConnection
    Public SQL As String
    Public Instruccion As SqlCommand

    Sub conectarBase()
        On Error GoTo Errores
        Dim Servidor As String = "estack.ddns.net"
        Dim Base As String = "UCES02"
        DaoCon = New SqlConnection("server=" & Servidor & ";database=" & Base & ";User ID=sa;Password=Ita1821!")
        DaoCon2 = New SqlConnection("server=" & Servidor & ";database=" & Base & ";User ID=sa;Password=Ita1821!")
        DaoCon.Open()
        Exit Sub
Errores:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub agregarAgrupacion(txtNombre As TextBox)
        On Error GoTo ErrorInsertar
        SQL = "INSERT INTO agrupacion ([nom agrupacion]) VALUES ('" & txtNombre.Text & "')"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Agrupacion agregada correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub modificarAgrupacion(txtCodigo As TextBox, txtNombre As TextBox)
        On Error GoTo ErrorInsertar
        SQL = "update agrupacion set [nom agrupacion] = '" & txtNombre.Text & "' where [id agrupacion] = '" & txtCodigo.Text & "'"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Agrupacion modificada correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub eliminarAgrupacion(txtCodigo As String)
        On Error GoTo ErrorInsertar

        Dim existe As Boolean

        existe = leerAgrupacionDeArticulos(txtCodigo)

        If existe = True Then
            MessageBox.Show("No se puede eliminar una agrupación asociada a un artículo existente", "¡ERROR!")
            Exit Sub
        Else
            SQL = "DELETE from agrupacion where ([id agrupacion]) = '" & txtCodigo & "'"
            Instruccion = New SqlCommand(SQL, DaoCon)
            Instruccion.ExecuteNonQuery()
            MsgBox("Agrupacion eliminada correctamente")
            Exit Sub
        End If

ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Public Function leerAgrupacionDeArticulos(txtCodigo As String) As Boolean
        Dim agrupacion As String
        Dim Rs As SqlDataReader
        SQL = "select * from articulo
               INNER JOIN agrupacion on articulo.[id agrupacion] = agrupacion.[id agrupacion]
               ORDER BY [ID articulo]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        While Rs.Read
            agrupacion = Rs(2)
            agrupacion = formatearCodigo(agrupacion)
            Console.WriteLine("Codigo agrupacion: " & agrupacion)

            If agrupacion = txtCodigo Then
                Rs.Close()
                Return True
            End If

        End While

        Rs.Close()

        Return False
    End Function

    Public Function leerAgrupacion(agrupacion As String)
        Dim Rs As SqlDataReader
        Dim nombreAgrupacion As String

        'Console.WriteLine("Agrupacion en leerAgrupacion: " & agrupacion)

        SQL = "select [nom agrupacion] from agrupacion where [id agrupacion] = '" & agrupacion & "'"

        DaoCon2.Open()

        Instruccion = New SqlCommand(SQL, DaoCon2)
        Rs = Instruccion.ExecuteReader()

        Rs.Read()
        nombreAgrupacion = Rs(0)
        Rs.Close()

        DaoCon2.Close()

        'Console.WriteLine("Agrupacion en leerAgrupacion: " & nombreAgrupacion)
        agrupacion = agrupacion & " " & nombreAgrupacion

        Return agrupacion

    End Function

    Sub leerAgrupacionesList(listAgrupaciones As ListBox)
        Dim codigo As String
        Dim Rs As SqlDataReader
        SQL = "select * from agrupacion ORDER BY [ID agrupacion]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            listAgrupaciones.Items.Add(codigo & " " & UCase(Rs(1)))
        End While

        Rs.Close()
    End Sub

    Sub leerAgrupacionesCombo(comboBoxAgrupaciones As ComboBox)
        Dim codigo As String
        Dim Rs As SqlDataReader
        SQL = "select * from agrupacion ORDER BY [ID agrupacion]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        comboBoxAgrupaciones.Items.Add("")

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            comboBoxAgrupaciones.Items.Add(codigo & " " & Rs(1))
        End While

        Rs.Close()
    End Sub



    Sub agregarArticulo(txtNombre As TextBox, txtCodigoAgrupacion As TextBox, txtPrecio As TextBox)
        On Error GoTo ErrorInsertar

        Dim precio As Double

        precio = Val(txtPrecio.Text)

        SQL = "INSERT INTO articulo ([nom articulo], [id agrupacion], [pco articulo]) 
               VALUES ('" & txtNombre.Text & "', '" & txtCodigoAgrupacion.Text & "', " & txtPrecio.Text & ")"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Articulo agregado correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub modificarArticulo(txtCodigo As TextBox, txtNombre As TextBox, txtCodigoAgrupacion As TextBox, txtPrecio As TextBox)
        On Error GoTo ErrorInsertar
        SQL = "update articulo
               set [nom articulo] = '" & txtNombre.Text & "', [id agrupacion] = '" & txtCodigoAgrupacion.Text & "', [pco articulo] = '" & txtPrecio.Text & "'
               where [id articulo] = '" & txtCodigo.Text & "'"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Articulo modificado correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub eliminarArticulo(txtNombre As TextBox)
        SQL = "DELETE from articulo where ([nom articulo]) = '" & txtNombre.Text & "'"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Articulo eliminado correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Public Function leerArticulo(articulo As String)
        Dim Rs As SqlDataReader
        Dim nombreArticulo As String

        SQL = "select [nom articulo] from articulo where [id articulo] = '" & articulo & "'"

        DaoCon2.Open()

        Instruccion = New SqlCommand(SQL, DaoCon2)
        Rs = Instruccion.ExecuteReader()

        Rs.Read()
        nombreArticulo = Rs(0)
        Rs.Close()

        DaoCon2.Close()

        'Console.WriteLine("Articulo en leerArticulo: " & nombreArticulo)
        articulo = articulo & " " & nombreArticulo

        Return articulo

    End Function

    Sub leerArticulos(listArticulos As ListBox)
        Dim codigo As String
        Dim agrupacion As String
        Dim precio As Double
        Dim Rs As SqlDataReader
        SQL = "select * from articulo
               INNER JOIN agrupacion on articulo.[id agrupacion] = agrupacion.[id agrupacion]
               ORDER BY [ID articulo]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            'Console.WriteLine("Codigo articulo: " & txtCodigo.Text)
            'Console.WriteLine("Nombre articulo: " & Rs(1))
            agrupacion = Rs(2)
            agrupacion = formatearCodigo(agrupacion)
            'Console.WriteLine("Codigo agrupacion: " & txtAgrupacion.Text)
            agrupacion = leerAgrupacion(agrupacion)
            'Console.WriteLine("Agrupacion entera: " & txtAgrupacion.Text)
            precio = Rs(3)
            'precio = formatearPrecio(precio)
            'Console.WriteLine("Precio articulo: " & Rs(3))
            listArticulos.Items.Add(codigo & " " & UCase(Rs(1)) & Space(15 - Len(Rs(1))) & UCase(agrupacion) & Space(20 - Len(agrupacion)) & precio)
            'listArticulos.Items.Add(codigo & " " & Rs(1) & Space(15 - Len(Rs(1))) & Rs(3))
        End While

        Rs.Close()
    End Sub

    Sub leerArticulosCombo(comboBoxArticulos As ComboBox)
        Dim codigo As String
        Dim Rs As SqlDataReader
        SQL = "select * from articulo ORDER BY [ID articulo]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        comboBoxArticulos.Items.Add("")

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            comboBoxArticulos.Items.Add(codigo & " " & Rs(1))
        End While

        Rs.Close()
    End Sub

    Public Function leerPrecioDeArticulo(txtCodigo As TextBox)

        Dim precio As Single
        Dim Rs As SqlDataReader
        SQL = "select [pco articulo] from articulo where [id articulo] = " & txtCodigo.Text & ""
        Instruccion = New SqlCommand(SQL, DaoCon)

        Rs = Instruccion.ExecuteReader()
        Rs.Read()

        precio = Rs(0)

        Rs.Close()

        Return precio

    End Function

    Sub agregarMovimiento(txtNombre As TextBox, comboBoxTipo As ComboBox)
        On Error GoTo ErrorInsertar
        SQL = "INSERT INTO tipomovi ([nom tipomovi], [tip tipomovi]) VALUES ('" & txtNombre.Text & "', '" & comboBoxTipo.Text & "')"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Tipo de movimiento agregado correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub modificarMovimiento(txtCodigo As TextBox, txtNombre As TextBox, txtTipo As ComboBox)
        On Error GoTo ErrorInsertar
        SQL = "update tipomovi set [nom tipomovi] = '" & txtNombre.Text & "', [tip tipomovi] = '" & txtTipo.Text & "' where [id tipomovi] = '" & txtCodigo.Text & "'"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Tipo de movimiento modificado correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub eliminarMovimiento(txtNombre As TextBox)
        SQL = "DELETE from tipomovi where ([nom tipomovi]) = '" & txtNombre.Text & "'"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Tipo de movimiento eliminado correctamente")
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Public Function leerMovimiento(movimiento As String)
        Dim Rs As SqlDataReader
        Dim nombreMovimiento As String

        SQL = "select [nom tipomovi] from tipomovi where [id tipomovi] = '" & movimiento & "'"

        DaoCon2.Open()

        Instruccion = New SqlCommand(SQL, DaoCon2)
        Rs = Instruccion.ExecuteReader()

        Rs.Read()
        nombreMovimiento = Rs(0)
        Rs.Close()

        DaoCon2.Close()

        'Console.WriteLine("TipoMovimiento en leerMovimiento: " & nombreMovimiento)
        movimiento = movimiento & " " & nombreMovimiento

        Return movimiento

    End Function

    Public Function leerTipoDeMovimiento(movimiento As String)
        Dim Rs As SqlDataReader
        Dim tipoMovimiento As String

        SQL = "select [tip tipomovi] from tipomovi where [id tipomovi] = '" & Mid(movimiento, 1, 1) & "'"

        DaoCon2.Open()

        Instruccion = New SqlCommand(SQL, DaoCon2)
        Rs = Instruccion.ExecuteReader()

        Rs.Read()
        tipoMovimiento = Rs(0)
        Rs.Close()

        DaoCon2.Close()

        'Console.WriteLine("TipoMovimiento en leerTipoDeMovimiento: " & tipoMovimiento)

        Return tipoMovimiento

    End Function

    Sub leerMovimientos(listMovimientos As ListBox)
        Dim codigo As String
        Dim Rs As SqlDataReader
        SQL = "select * from tipomovi ORDER BY [ID tipomovi]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            'Console.WriteLine("Codigo movimiento: " & txtCodigo.Text)
            'Console.WriteLine("Nombre movimiento: " & Rs(1))
            'Console.WriteLine("Tipo movimiento: " & Rs(2))
            listMovimientos.Items.Add(codigo & " " & UCase(Rs(1)) & Space(15 - Len(Rs(1))) & " " & Rs(2))
        End While

        Rs.Close()
    End Sub

    Sub leerMovimientosCombo(comboBoxMovimientos As ComboBox)
        Dim codigo As String
        Dim Rs As SqlDataReader
        SQL = "select * from tipomovi ORDER BY [ID tipomovi]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        comboBoxMovimientos.Items.Add("")

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            comboBoxMovimientos.Items.Add(codigo & " " & Rs(1) & " " & Rs(2))
        End While

        Rs.Close()
    End Sub

    Sub agregarMovimientoDeCantidades(txtCodigoTipo As TextBox, txtCodigoArticulo As TextBox, dateTimeFecha As DateTimePicker,
                                      txtCantidad As TextBox, txtPrecioUnitario As TextBox, txtObservacion As TextBox)
        On Error GoTo ErrorInsertar

        Dim fecha As String
        Dim precioUnitario As Double
        Dim cantidad As Double
        Dim precioTotal As Double

        fecha = dateTimeFecha.Text

        'A continuación, se seteará el precio en la BBDD. En caso que sea decimal, primero se reemplaza la "," por el
        '"." ya que asi se podrá hacer la cuenta que dará un resultado con ",". Una vez realizada, se pasa el
        'resultado a un String que reemplace nuevamente la "," por el "." para finalmente guardar ese resultado en
        'la BBDD.

        'MsgBox("Precio unitario normal en String: " & txtPrecioUnitario.Text)
        txtPrecioUnitario.Text = txtPrecioUnitario.Text.Replace(",", ".")
        'MsgBox("Precio unitario con punto en String: " & txtPrecioUnitario.Text)
        precioUnitario = Val(txtPrecioUnitario.Text)
        'MsgBox("Precio unitario en Single: " & precioUnitario)
        cantidad = Val(txtCantidad.Text)
        precioTotal = precioUnitario * cantidad
        'MsgBox("Precio total: " & precioTotal)
        txtPrecioUnitario.Text = precioTotal
        'MsgBox("Precio total en String: " & txtPrecioUnitario.Text)
        txtPrecioUnitario.Text = txtPrecioUnitario.Text.Replace(",", ".")
        'MsgBox("Precio a guardar en BBDD: " & txtPrecioUnitario.Text)

        'MsgBox("Codigo tipo = /" & txtCodigoTipo.Text & " Codigo articulo = /" & txtCodigoArticulo.Text & " Fecha = /" & fecha & " Cantidad = /" & txtCantidad.Text & " Precio = /" & precio & " Observacion = /" & txtObservacion.Text)

        SQL = "INSERT INTO movimiento ([id tipomovi], [id articulo], [fec movimiento], [can movimiento], [pre movimiento], [obs movimiento])
               VALUES ('" & txtCodigoTipo.Text & "', '" & txtCodigoArticulo.Text & "', '" & fecha & "',
                       '" & txtCantidad.Text & "', " & txtPrecioUnitario.Text & ", '" & txtObservacion.Text & "')"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Instruccion.ExecuteNonQuery()
        MsgBox("Movimiento agregado correctamente")
        txtPrecioUnitario.Text = precioUnitario
        Exit Sub
ErrorInsertar:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Sub leerMovimientosDeCantidades(dateTimeFecha As DateTimePicker, listMovimientos As ListBox)
        Dim codigo As String
        Dim movimiento As String
        Dim articulo As String
        Dim fecha As String
        Dim cantidad As String
        Dim Rs As SqlDataReader
        SQL = "select * from movimiento
               INNER JOIN tipomovi on movimiento.[id tipomovi] = tipomovi.[id tipomovi]
               INNER JOIN articulo on movimiento.[id articulo] = articulo.[id articulo]
               ORDER BY [ID movimiento]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        While Rs.Read
            codigo = Rs(0)
            codigo = formatearCodigo(codigo)
            'Console.WriteLine("Codigo movimiento: " & codigo)
            movimiento = Rs(1)
            'Console.WriteLine("Tipo movimiento: " & movimiento)
            movimiento = leerMovimiento(movimiento)
            'Console.WriteLine("Tipo movimiento entero: " & movimiento)
            articulo = Rs(2)
            'Console.WriteLine("Articulo movimiento: " & articulo)
            articulo = leerArticulo(articulo)
            'Console.WriteLine("Articulo movimiento entero: " & articulo)
            dateTimeFecha.Text = Rs(3)
            fecha = dateTimeFecha.Text
            'Console.WriteLine("Fecha movimiento: " & fecha)
            'fecha = formatearFecha(dateTimeFecha.Text)
            'Console.WriteLine("Fecha movimiento formateada: " & fecha)
            cantidad = Rs(4)
            cantidad = formatearCodigo(cantidad)
            'Console.WriteLine("Cantidad movimiento: " & cantidad)
            'Console.WriteLine("Precio total movimiento: " & Rs(5))
            'Console.WriteLine("Observacion movimiento: " & Rs(6))
            listMovimientos.Items.Add(codigo & " " & UCase(movimiento) & Space(15 - Len(movimiento)) &
                                      UCase(articulo) & Space(15 - Len(articulo)) & fecha & Space(15 - Len(fecha)) &
                                      cantidad & Space(7 - Len(cantidad)) & Rs(5))
        End While

        Rs.Close()
    End Sub

    Sub leerInformes(txtArticulo As String, dateTimeFecha As DateTimePicker, listInformes As ListBox)
        Dim codigo As String
        Dim movimiento As String
        Dim tipoMovimiento As String
        Dim fecha As String
        Dim cantidad As String
        Dim saldo As Integer

        saldo = 0

        Dim Rs As SqlDataReader
        SQL = "select [fec movimiento], [id tipomovi], [can movimiento], [id movimiento] from movimiento
               where [id articulo] = '" & Mid(txtArticulo, 1, 3) & "'
               ORDER BY [ID movimiento]"
        Instruccion = New SqlCommand(SQL, DaoCon)
        Rs = Instruccion.ExecuteReader()

        While Rs.Read
            dateTimeFecha.Text = Rs(0)
            fecha = dateTimeFecha.Text
            'Console.WriteLine("Fecha movimiento: " & fecha)
            movimiento = Rs(1)
            'Console.WriteLine("Tipo movimiento: " & movimiento)
            movimiento = leerMovimiento(movimiento)
            'Console.WriteLine("Tipo movimiento entero: " & movimiento)
            tipoMovimiento = leerTipoDeMovimiento(movimiento)
            'Console.WriteLine("Tipo tipo movimiento: " & tipoMovimiento)
            cantidad = Rs(2)
            cantidad = formatearCodigo(cantidad)
            'Console.WriteLine("Cantidad movimiento: " & cantidad)
            codigo = Rs(3)
            codigo = formatearCodigo(codigo)
            'Console.WriteLine("Codigo movimiento: " & codigo)

            If tipoMovimiento = "E" Then
                saldo = saldo + Val(cantidad)
                listInformes.Items.Add(fecha & Space(2) & UCase(movimiento) & Space(14 - Len(movimiento)) & " " &
                                   cantidad & Space(6) & Space(5) & saldo & Space(10) & codigo)
            Else
                saldo = saldo - Val(cantidad)
                listInformes.Items.Add(fecha & Space(2) & UCase(movimiento) & Space(14 - Len(movimiento)) & " " &
                                   Space(6) & cantidad & Space(5) & saldo & Space(10) & codigo)
            End If
        End While

        Rs.Close()
    End Sub

    Sub leerObservacion(codigo As String)
        Dim Rs As SqlDataReader
        Dim observacion As String

        SQL = "select [obs movimiento] from movimiento where [id movimiento] = '" & codigo & "'"

        DaoCon2.Open()

        Instruccion = New SqlCommand(SQL, DaoCon2)
        Rs = Instruccion.ExecuteReader()

        Rs.Read()
        observacion = Rs(0)
        Rs.Close()

        DaoCon2.Close()

        frmObservacion.txtObservacion.Text = observacion
    End Sub

    Public Function formatearCodigo(codigo As String)
        codigo = Format(Val(codigo), "000")
        Return codigo
    End Function

    Public Function formatearPrecio(precio As String)
        precio = Format(Val(precio), "$##0,##")
        Return precio
    End Function

    '    Sub xxx()
    '        On Error GoTo ErrorInsertar
    '        SQL = "delete from articulo where [id articulo] = 25"
    '        Instruccion = New SqlCommand(SQL, DaoCon)
    '        Instruccion.ExecuteNonQuery()
    '        MsgBox("Delete exitoso")
    '        Exit Sub
    'ErrorInsertar:
    '        MsgBox(Err.Description)
    '        Exit Sub
    '    End Sub

End Module
