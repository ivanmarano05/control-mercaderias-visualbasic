﻿Public Class frmAgrupaciones

    Private Sub frmAgrupaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnAgregar.Enabled = False
        btnModificar.Enabled = False
        btnEliminar.Enabled = False

        setearToolTip()
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        agregar()
    End Sub

    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        modificar()
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        frmBusquedaAgrupaciones.txtBusqueda.Text = ""
        frmBusquedaAgrupaciones.listAux.Items.Clear()
        frmBusquedaAgrupaciones.ShowDialog()
    End Sub

    Private Sub txtNombre_TextChanged(sender As Object, e As EventArgs) Handles txtNombre.TextChanged
        estadoBotones()
        cantidadDeCaracteres(txtNombre, 15)
    End Sub

    Sub limpiar()
        txtCodigo.Text = ""
        txtNombre.Text = ""
    End Sub

    Sub agregar()
        agregarAgrupacion(txtNombre)

        limpiar()
    End Sub

    Sub modificar()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea modificar la agrupación?", vbYesNo, "Atención")
        If opcion = vbYes Then
            modificarAgrupacion(txtCodigo, txtNombre)
        End If

        limpiar()
    End Sub

    Sub eliminar()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea eliminar la agrupación?", vbYesNo, "Atención")
        If opcion = vbYes Then
            eliminarAgrupacion(txtCodigo.Text)
        End If

        limpiar()
    End Sub

    Sub estadoBotones()
        If txtNombre.Text = "" Then
            btnAgregar.Enabled = False
            btnModificar.Enabled = False
            btnEliminar.Enabled = False
        Else
            If btnModificar.Enabled = True Then
                btnAgregar.Enabled = False
            Else
                btnAgregar.Enabled = True
            End If
        End If
    End Sub

    Sub setearToolTip()
        toolTip1.SetToolTip(btnLimpiar, "Limpiar")
        toolTip1.SetToolTip(btnAgregar, "Agregar")
        toolTip1.SetToolTip(btnModificar, "Modificar")
        toolTip1.SetToolTip(btnEliminar, "Eliminar")
        toolTip1.SetToolTip(btnBuscar, "Buscar")
    End Sub

End Class