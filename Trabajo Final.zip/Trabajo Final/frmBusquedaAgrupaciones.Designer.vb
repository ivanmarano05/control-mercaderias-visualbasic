﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusquedaAgrupaciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBusquedaAgrupaciones))
        Me.listAgrupaciones = New System.Windows.Forms.ListBox()
        Me.txtAux = New System.Windows.Forms.TextBox()
        Me.txtBusqueda = New System.Windows.Forms.TextBox()
        Me.listAux = New System.Windows.Forms.ListBox()
        Me.lblAgrupacion = New System.Windows.Forms.Label()
        Me.lblCodigo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'listAgrupaciones
        '
        Me.listAgrupaciones.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listAgrupaciones.Font = New System.Drawing.Font("Courier New", 15.0!)
        Me.listAgrupaciones.FormattingEnabled = True
        Me.listAgrupaciones.ItemHeight = 22
        Me.listAgrupaciones.Location = New System.Drawing.Point(35, 75)
        Me.listAgrupaciones.Name = "listAgrupaciones"
        Me.listAgrupaciones.Size = New System.Drawing.Size(249, 180)
        Me.listAgrupaciones.TabIndex = 0
        '
        'txtAux
        '
        Me.txtAux.Location = New System.Drawing.Point(175, 221)
        Me.txtAux.Name = "txtAux"
        Me.txtAux.Size = New System.Drawing.Size(100, 20)
        Me.txtAux.TabIndex = 1
        '
        'txtBusqueda
        '
        Me.txtBusqueda.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtBusqueda.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.txtBusqueda.Location = New System.Drawing.Point(57, 21)
        Me.txtBusqueda.Name = "txtBusqueda"
        Me.txtBusqueda.Size = New System.Drawing.Size(192, 25)
        Me.txtBusqueda.TabIndex = 2
        '
        'listAux
        '
        Me.listAux.Font = New System.Drawing.Font("Courier New", 9.75!)
        Me.listAux.FormattingEnabled = True
        Me.listAux.ItemHeight = 16
        Me.listAux.Location = New System.Drawing.Point(545, 61)
        Me.listAux.Name = "listAux"
        Me.listAux.Size = New System.Drawing.Size(311, 148)
        Me.listAux.TabIndex = 3
        '
        'lblAgrupacion
        '
        Me.lblAgrupacion.AutoSize = True
        Me.lblAgrupacion.BackColor = System.Drawing.Color.Transparent
        Me.lblAgrupacion.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblAgrupacion.Location = New System.Drawing.Point(89, 59)
        Me.lblAgrupacion.Name = "lblAgrupacion"
        Me.lblAgrupacion.Size = New System.Drawing.Size(77, 14)
        Me.lblAgrupacion.TabIndex = 16
        Me.lblAgrupacion.Text = "Agrupación"
        '
        'lblCodigo
        '
        Me.lblCodigo.AutoSize = True
        Me.lblCodigo.BackColor = System.Drawing.Color.Transparent
        Me.lblCodigo.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblCodigo.Location = New System.Drawing.Point(32, 59)
        Me.lblCodigo.Name = "lblCodigo"
        Me.lblCodigo.Size = New System.Drawing.Size(51, 14)
        Me.lblCodigo.TabIndex = 15
        Me.lblCodigo.Text = "Código"
        '
        'frmBusquedaAgrupaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(315, 267)
        Me.Controls.Add(Me.lblAgrupacion)
        Me.Controls.Add(Me.lblCodigo)
        Me.Controls.Add(Me.listAux)
        Me.Controls.Add(Me.txtBusqueda)
        Me.Controls.Add(Me.txtAux)
        Me.Controls.Add(Me.listAgrupaciones)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(331, 306)
        Me.MinimumSize = New System.Drawing.Size(331, 306)
        Me.Name = "frmBusquedaAgrupaciones"
        Me.Text = "Búsqueda Agrupaciones"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents listAgrupaciones As ListBox
    Friend WithEvents txtAux As TextBox
    Friend WithEvents txtBusqueda As TextBox
    Friend WithEvents listAux As ListBox
    Friend WithEvents lblAgrupacion As Label
    Friend WithEvents lblCodigo As Label
End Class
