﻿Public Class frmBusquedaArticulos

    Private Sub frmBusquedaArticulos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        listArticulos.Items.Clear()
        leerArticulos(listArticulos)
        leerArticulos(listAux)
        txtAux.Visible = False
    End Sub

    Private Sub listArticulos_DoubleClick(sender As Object, e As EventArgs) Handles listArticulos.DoubleClick
        pasar()
    End Sub

    Sub pasar()
        Dim codigo As String
        Dim articulo As String
        Dim agrupacion As String
        Dim precio As String

        txtAux.Text = listArticulos.SelectedItem
        codigo = Mid(txtAux.Text, 1, 3)
        articulo = Mid(txtAux.Text, 5, 15)
        agrupacion = Mid(txtAux.Text, 20, 20)
        precio = Mid(txtAux.Text, 40, Len(txtAux.Text) - 1)
        precio = precio.Replace(",", ".")
        frmArticulos.txtCodigo.Text = codigo
        articulo = sacarEspacios(articulo)
        agrupacion = sacarEspacios(agrupacion)
        frmArticulos.txtNombre.Text = articulo

        articulo = Mid(frmArticulos.txtNombre.Text, 2, Len(frmArticulos.txtNombre.Text))
        articulo = LCase(articulo)
        frmArticulos.txtNombre.Text = Mid(frmArticulos.txtNombre.Text, 1, 1)
        frmArticulos.txtNombre.Text = frmArticulos.txtNombre.Text + articulo

        frmArticulos.comboBoxAgrupaciones.Text = agrupacion
        frmArticulos.txtPrecio.Text = precio
        'MsgBox("Codigo = /" & codigo & ". Articulo = /" & articulo & ". Agrupacion = /" & agrupacion & ". Precio = /" & precio & ".")
        frmArticulos.btnAgregar.Enabled = False
        frmArticulos.btnModificar.Enabled = True
        frmArticulos.btnEliminar.Enabled = True
        frmArticulos.pasarDatosAgrupacion()
        Me.Close()
    End Sub

    Public Function sacarEspacios(articulo As String) As String

        Dim I As Integer

        For I = 1 To Len(articulo)
            If articulo(Len(articulo) - 1) = " " Then
                articulo = articulo.Remove(Len(articulo) - 1, 1)
                'Console.WriteLine(articulo & ".")
            End If
        Next

        Return articulo

    End Function

    Private Sub txtBusqueda_TextChanged(sender As Object, e As EventArgs) Handles txtBusqueda.TextChanged
        buscarElemento(txtBusqueda)
    End Sub

    Sub buscarElemento(txtBusqueda As TextBox)

        Dim I As Integer

        listArticulos.Items.Clear()

        For I = 0 To listAux.Items.Count - 1
            Select Case listAux.Items(I).IndexOf(UCase(txtBusqueda.Text))
                Case <> -1
                    listArticulos.Items.Add(listAux.Items(I))
            End Select
        Next

    End Sub
End Class