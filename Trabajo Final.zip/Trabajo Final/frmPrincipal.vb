﻿Public Class frmPrincipal

    Private Sub frmPrincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectarBase() 'Conecta con la BBDD
    End Sub

    Private Sub frmPrincipal_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        DaoCon.Close() 'Cierra la conexión de DaoCon
    End Sub

    Private Sub AgrupacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgrupacionesToolStripMenuItem.Click
        abrirAgrupaciones()
    End Sub

    Private Sub ArtículosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ArtículosToolStripMenuItem.Click
        abrirArticulos()
    End Sub

    Private Sub TiposDeMovimientosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TiposDeMovimientosToolStripMenuItem.Click
        abrirMovimientos()
    End Sub

    Private Sub MovimientosDeCantidadesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MovimientosDeCantidadesToolStripMenuItem.Click
        abrirMovimientosDeCantidades()
    End Sub

    Private Sub InformesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InformesToolStripMenuItem.Click
        frmInformes.Show()
    End Sub

    Private Sub btnAgrupaciones_Click(sender As Object, e As EventArgs) Handles btnAgrupaciones.Click
        abrirAgrupaciones()
    End Sub

    Private Sub btnArticulos_Click(sender As Object, e As EventArgs) Handles btnArticulos.Click
        abrirArticulos()
    End Sub

    Private Sub btnTipo_Click(sender As Object, e As EventArgs) Handles btnTipo.Click
        abrirMovimientos()
    End Sub

    Private Sub btnMovimientos_Click(sender As Object, e As EventArgs) Handles btnMovimientos.Click
        abrirMovimientosDeCantidades()
    End Sub

    Sub abrirAgrupaciones()
        frmAgrupaciones.Show()
    End Sub

    Sub abrirArticulos()
        frmArticulos.Show()
    End Sub

    Sub abrirMovimientos()
        frmMovimientos.Show()
    End Sub

    Sub abrirMovimientosDeCantidades()
        frmMovimientosDeCantidades.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmInformes.Show()
    End Sub
End Class
