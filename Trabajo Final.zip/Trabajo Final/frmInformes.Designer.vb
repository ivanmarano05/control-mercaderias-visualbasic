﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmInformes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmInformes))
        Me.comboBoxArticulo = New System.Windows.Forms.ComboBox()
        Me.listInformes = New System.Windows.Forms.ListBox()
        Me.lblSaldo = New System.Windows.Forms.Label()
        Me.lblEntrada = New System.Windows.Forms.Label()
        Me.lblMovimiento = New System.Windows.Forms.Label()
        Me.lblFecha = New System.Windows.Forms.Label()
        Me.lblSalida = New System.Windows.Forms.Label()
        Me.btnObservacion = New System.Windows.Forms.Button()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.dateTimeFecha = New System.Windows.Forms.DateTimePicker()
        Me.txtAux = New System.Windows.Forms.TextBox()
        Me.txtCodigoAux = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'comboBoxArticulo
        '
        Me.comboBoxArticulo.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.comboBoxArticulo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxArticulo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.comboBoxArticulo.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.comboBoxArticulo.FormattingEnabled = True
        Me.comboBoxArticulo.Location = New System.Drawing.Point(172, 30)
        Me.comboBoxArticulo.Name = "comboBoxArticulo"
        Me.comboBoxArticulo.Size = New System.Drawing.Size(165, 26)
        Me.comboBoxArticulo.TabIndex = 0
        '
        'listInformes
        '
        Me.listInformes.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.listInformes.Font = New System.Drawing.Font("Courier New", 14.0!)
        Me.listInformes.FormattingEnabled = True
        Me.listInformes.ItemHeight = 21
        Me.listInformes.Location = New System.Drawing.Point(12, 103)
        Me.listInformes.Name = "listInformes"
        Me.listInformes.Size = New System.Drawing.Size(521, 340)
        Me.listInformes.TabIndex = 7
        '
        'lblSaldo
        '
        Me.lblSaldo.AutoSize = True
        Me.lblSaldo.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblSaldo.Location = New System.Drawing.Point(462, 86)
        Me.lblSaldo.Name = "lblSaldo"
        Me.lblSaldo.Size = New System.Drawing.Size(42, 14)
        Me.lblSaldo.TabIndex = 23
        Me.lblSaldo.Text = "Saldo"
        '
        'lblEntrada
        '
        Me.lblEntrada.AutoSize = True
        Me.lblEntrada.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblEntrada.Location = New System.Drawing.Point(300, 86)
        Me.lblEntrada.Name = "lblEntrada"
        Me.lblEntrada.Size = New System.Drawing.Size(57, 14)
        Me.lblEntrada.TabIndex = 22
        Me.lblEntrada.Text = "Entrada"
        '
        'lblMovimiento
        '
        Me.lblMovimiento.AutoSize = True
        Me.lblMovimiento.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblMovimiento.Location = New System.Drawing.Point(146, 86)
        Me.lblMovimiento.Name = "lblMovimiento"
        Me.lblMovimiento.Size = New System.Drawing.Size(128, 14)
        Me.lblMovimiento.TabIndex = 19
        Me.lblMovimiento.Text = "Tipo de Movimiento"
        '
        'lblFecha
        '
        Me.lblFecha.AutoSize = True
        Me.lblFecha.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblFecha.Location = New System.Drawing.Point(38, 86)
        Me.lblFecha.Name = "lblFecha"
        Me.lblFecha.Size = New System.Drawing.Size(44, 14)
        Me.lblFecha.TabIndex = 18
        Me.lblFecha.Text = "Fecha"
        '
        'lblSalida
        '
        Me.lblSalida.AutoSize = True
        Me.lblSalida.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblSalida.Location = New System.Drawing.Point(373, 86)
        Me.lblSalida.Name = "lblSalida"
        Me.lblSalida.Size = New System.Drawing.Size(45, 14)
        Me.lblSalida.TabIndex = 24
        Me.lblSalida.Text = "Salida"
        '
        'btnObservacion
        '
        Me.btnObservacion.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.btnObservacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnObservacion.Location = New System.Drawing.Point(372, 21)
        Me.btnObservacion.Name = "btnObservacion"
        Me.btnObservacion.Size = New System.Drawing.Size(97, 43)
        Me.btnObservacion.TabIndex = 25
        Me.btnObservacion.Text = "Ver Observacion"
        Me.btnObservacion.UseVisualStyleBackColor = False
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLimpiar.Image = CType(resources.GetObject("btnLimpiar.Image"), System.Drawing.Image)
        Me.btnLimpiar.Location = New System.Drawing.Point(65, 18)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(75, 50)
        Me.btnLimpiar.TabIndex = 26
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'dateTimeFecha
        '
        Me.dateTimeFecha.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.CalendarTitleBackColor = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.CalendarTitleForeColor = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.CalendarTrailingForeColor = System.Drawing.SystemColors.ScrollBar
        Me.dateTimeFecha.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.dateTimeFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateTimeFecha.Location = New System.Drawing.Point(476, 32)
        Me.dateTimeFecha.Name = "dateTimeFecha"
        Me.dateTimeFecha.Size = New System.Drawing.Size(73, 29)
        Me.dateTimeFecha.TabIndex = 31
        Me.dateTimeFecha.Value = New Date(2022, 11, 4, 2, 36, 0, 0)
        '
        'txtAux
        '
        Me.txtAux.Location = New System.Drawing.Point(201, 414)
        Me.txtAux.Name = "txtAux"
        Me.txtAux.Size = New System.Drawing.Size(316, 20)
        Me.txtAux.TabIndex = 32
        '
        'txtCodigoAux
        '
        Me.txtCodigoAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCodigoAux.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.txtCodigoAux.Location = New System.Drawing.Point(201, 60)
        Me.txtCodigoAux.Name = "txtCodigoAux"
        Me.txtCodigoAux.Size = New System.Drawing.Size(100, 25)
        Me.txtCodigoAux.TabIndex = 33
        '
        'frmInformes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(544, 455)
        Me.Controls.Add(Me.txtCodigoAux)
        Me.Controls.Add(Me.txtAux)
        Me.Controls.Add(Me.dateTimeFecha)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnObservacion)
        Me.Controls.Add(Me.lblSalida)
        Me.Controls.Add(Me.lblSaldo)
        Me.Controls.Add(Me.lblEntrada)
        Me.Controls.Add(Me.lblMovimiento)
        Me.Controls.Add(Me.lblFecha)
        Me.Controls.Add(Me.listInformes)
        Me.Controls.Add(Me.comboBoxArticulo)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(560, 494)
        Me.MinimumSize = New System.Drawing.Size(560, 494)
        Me.Name = "frmInformes"
        Me.Text = "Informes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents comboBoxArticulo As ComboBox
    Friend WithEvents listInformes As ListBox
    Friend WithEvents lblSaldo As Label
    Friend WithEvents lblEntrada As Label
    Friend WithEvents lblMovimiento As Label
    Friend WithEvents lblFecha As Label
    Friend WithEvents lblSalida As Label
    Friend WithEvents btnObservacion As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents dateTimeFecha As DateTimePicker
    Friend WithEvents txtAux As TextBox
    Friend WithEvents txtCodigoAux As TextBox
End Class
