﻿Public Class frmBusquedaMovimientosDeCantidades
    Private Sub frmBusquedaMovimientosDeCantidades_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        listMovimientosDeCantidades.Items.Clear() 'Se limpia la lista de movimientos para evitar repetidos

        'A continuación, se leen ambas listas con el mismo método para trabajar en conjunto

        leerMovimientosDeCantidades(frmMovimientosDeCantidades.dateTimeFecha, listMovimientosDeCantidades)
        leerMovimientosDeCantidades(frmMovimientosDeCantidades.dateTimeFecha, listAux)
        txtAux.Visible = False
        txtCodigoAux.Visible = False
        btnObservacion.Enabled = False
    End Sub

    Private Sub txtBusqueda_TextChanged(sender As Object, e As EventArgs) Handles txtBusqueda.TextChanged
        buscarElemento(txtBusqueda)
    End Sub

    Sub buscarElemento(txtBusqueda As TextBox)

        'En caso que el texto introducido en el txt vaya coincidiendo, se pasan los datos de la lista auxiliar (que
        'siempre tendrá cargados todos los movimientos) a la lista real

        Dim I As Integer

        listMovimientosDeCantidades.Items.Clear() 'Se eliminan los elementos para evitar repetidos

        For I = 0 To listAux.Items.Count - 1
            Select Case listAux.Items(I).IndexOf(UCase(txtBusqueda.Text))
                Case <> -1
                    listMovimientosDeCantidades.Items.Add(listAux.Items(I))
            End Select
        Next

    End Sub

    Private Sub listMovimientosDeCantidades_SelectedIndexChanged(sender As Object, e As EventArgs) Handles listMovimientosDeCantidades.SelectedIndexChanged
        Dim codigo As String

        txtAux.Text = listMovimientosDeCantidades.SelectedItem
        codigo = Mid(txtAux.Text, 1, 3)
        txtCodigoAux.Text = codigo
        btnObservacion.Enabled = True
    End Sub

    Private Sub btnObservacion_Click(sender As Object, e As EventArgs) Handles btnObservacion.Click

        'Se abre el formulario de observacion para poder verla en un txt de ese mismo formulario

        leerObservacion(txtCodigoAux.Text)
        frmObservacion.ShowDialog()
    End Sub

End Class