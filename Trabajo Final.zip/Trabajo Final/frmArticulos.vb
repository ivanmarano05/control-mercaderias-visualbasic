﻿Public Class frmArticulos

    Private Sub frmArticulos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnAgregar.Enabled = False
        btnModificar.Enabled = False
        btnEliminar.Enabled = False
        leerAgrupacionesCombo(comboBoxAgrupaciones)
        txtCodigoAgrupacionAux.Visible = False
        txtAgrupacionAux.Visible = False

        setearToolTip()
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        agregar()
    End Sub

    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        modificar()
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        frmBusquedaArticulos.txtBusqueda.Text = ""
        frmBusquedaArticulos.listAux.Items.Clear()
        frmBusquedaArticulos.ShowDialog()
    End Sub

    Sub pasarDatosAgrupacion()
        Dim codigo As String
        Dim agrupacion As String

        If comboBoxAgrupaciones.SelectedIndex <> 0 Then
            txtAgrupacionAux.Text = comboBoxAgrupaciones.Text
            codigo = Mid(txtAgrupacionAux.Text, 1, 3)
            agrupacion = Mid(txtAgrupacionAux.Text, 5, Len(txtAgrupacionAux.Text) - 1)
            'MsgBox("Codigo = " & codigo & " Agrupacion = " & agrupacion)
            txtCodigoAgrupacionAux.Text = codigo
            txtAgrupacionAux.Text = agrupacion
        End If

    End Sub

    Sub limpiar()
        txtCodigo.Text = ""
        txtNombre.Text = ""
        comboBoxAgrupaciones.SelectedIndex = 0
        txtPrecio.Text = ""

        txtCodigoAgrupacionAux.Text = ""
        txtAgrupacionAux.Text = ""
    End Sub

    Sub agregar()
        agregarArticulo(txtNombre, txtCodigoAgrupacionAux, txtPrecio)

        limpiar()
    End Sub

    Sub modificar()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea modificar el artículo?", vbYesNo, "Atención")
        If opcion = vbYes Then
            modificarArticulo(txtCodigo, txtNombre, txtCodigoAgrupacionAux, txtPrecio)
        End If

        limpiar()
    End Sub

    Sub eliminar()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea eliminar el artículo?", vbYesNo, "Atención")
        If opcion = vbYes Then
            eliminarArticulo(txtNombre)
        End If

        limpiar()
    End Sub

    Private Sub txtNombre_TextChanged(sender As Object, e As EventArgs) Handles txtNombre.TextChanged
        estadoBotones()
        cantidadDeCaracteres(txtNombre, 15)
    End Sub

    Private Sub comboBoxAgrupaciones_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBoxAgrupaciones.SelectedIndexChanged
        pasarDatosAgrupacion()
        estadoBotones()
    End Sub

    Private Sub txtPrecio_TextChanged(sender As Object, e As EventArgs) Handles txtPrecio.TextChanged
        estadoBotones()
        validarPrecio(txtPrecio, 8, 2)
    End Sub

    Sub estadoBotones()
        If txtNombre.Text = "" Or comboBoxAgrupaciones.Text = "" Or txtPrecio.Text = "" Then
            btnAgregar.Enabled = False
            btnModificar.Enabled = False
            btnEliminar.Enabled = False
        Else
            If btnModificar.Enabled = True Then
                btnAgregar.Enabled = False
            Else
                btnAgregar.Enabled = True
            End If
        End If
    End Sub

    Sub setearToolTip()
        toolTip1.SetToolTip(btnLimpiar, "Limpiar")
        toolTip1.SetToolTip(btnAgregar, "Agregar")
        toolTip1.SetToolTip(btnModificar, "Modificar")
        toolTip1.SetToolTip(btnEliminar, "Eliminar")
        toolTip1.SetToolTip(btnBuscar, "Buscar")
    End Sub

End Class