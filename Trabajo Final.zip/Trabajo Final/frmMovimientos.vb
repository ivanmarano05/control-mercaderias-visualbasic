﻿Public Class frmMovimientos
    Private Sub frmMovimientos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Se agregan los 2 tipos de movimientos y el vacio

        comboBoxTipo.Items.Add("")
        comboBoxTipo.Items.Add("E")
        comboBoxTipo.Items.Add("S")
        btnAgregar.Enabled = False
        btnModificar.Enabled = False
        btnEliminar.Enabled = False

        setearToolTip()
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        agregar()
    End Sub

    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        modificar()
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        eliminar()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click

        'Se limpia el txt de búsqueda y la lista auxiliar del formulario de búsqueda para evitar repeticiones

        frmBusquedaMovimientos.txtBusqueda.Text = ""
        frmBusquedaMovimientos.listAux.Items.Clear()
        frmBusquedaMovimientos.ShowDialog()
    End Sub

    Sub limpiar()
        txtCodigo.Text = ""
        txtNombre.Text = ""
        comboBoxTipo.SelectedIndex = 0
    End Sub

    Sub agregar()
        agregarMovimiento(txtNombre, comboBoxTipo)

        limpiar()
    End Sub

    Sub modificar()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea modificar el tipo de movimiento?", vbYesNo, "Atención")
        If opcion = vbYes Then
            modificarMovimiento(txtCodigo, txtNombre, comboBoxTipo)
        End If

        limpiar()
    End Sub

    Sub eliminar()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea eliminar el tipo de movimiento?", vbYesNo, "Atención")
        If opcion = vbYes Then
            eliminarMovimiento(txtNombre)
        End If

        limpiar()
    End Sub

    Private Sub txtNombre_TextChanged(sender As Object, e As EventArgs) Handles txtNombre.TextChanged
        estadoBotones()
        cantidadDeCaracteres(txtNombre, 15)
    End Sub

    Private Sub comboBoxTipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBoxTipo.SelectedIndexChanged
        estadoBotones()
    End Sub

    Sub estadoBotones()

        'En caso que no se llenen todos los campos, no se podrá agregar, modificar ni eliminar el movimiento

        If txtNombre.Text = "" Or comboBoxTipo.Text = "" Then
            btnAgregar.Enabled = False
            btnModificar.Enabled = False
            btnEliminar.Enabled = False
        Else
            If btnModificar.Enabled = True Then
                btnAgregar.Enabled = False
            Else
                btnAgregar.Enabled = True
            End If
        End If

    End Sub

    Sub setearToolTip()
        toolTip1.SetToolTip(btnLimpiar, "Limpiar")
        toolTip1.SetToolTip(btnAgregar, "Agregar")
        toolTip1.SetToolTip(btnModificar, "Modificar")
        toolTip1.SetToolTip(btnEliminar, "Eliminar")
        toolTip1.SetToolTip(btnBuscar, "Buscar")
    End Sub
End Class