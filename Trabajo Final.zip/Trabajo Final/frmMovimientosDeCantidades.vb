﻿Public Class frmMovimientosDeCantidades
    Private Sub frmMovimientosDeCantidades_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        leerMovimientosCombo(comboBoxMovimientos) 'Llena el comboBox con los tipos de movimiento existentes
        leerArticulosCombo(comboBoxArticulo) 'Llena el comboBox con los artículos existentes
        btnAgregar.Enabled = False
        dateTimeFecha.CustomFormat = "dd/MM/yyyy" 'Setea el formato en que se mostrará la fecha

        'A continuación, se ocultan todos los txt que sirven de apoyo

        txtCodigoTipoAux.Visible = False
        txtTipoAux.Visible = False
        txtTipoTipoAux.Visible = False
        txtCodigoArticuloAux.Visible = False
        txtArticuloAux.Visible = False

        setearToolTip()
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        limpiar()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        agregarMovimientoDeCantidades(txtCodigoTipoAux, txtCodigoArticuloAux, dateTimeFecha, txtCantidad, txtPrecioArticuloAux, txtObservacion)

        limpiar()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click

        'Se limpia el txt de búsqueda y la lista auxiliar del formulario de búsqueda para evitar repeticiones

        frmBusquedaMovimientosDeCantidades.txtBusqueda.Text = ""
        frmBusquedaMovimientosDeCantidades.listAux.Items.Clear()
        frmBusquedaMovimientosDeCantidades.ShowDialog()
    End Sub

    Sub pasarDatosMovimiento()
        Dim codigo As String
        Dim tipo As String
        Dim tipoTipo As String

        'En caso que el index sea distinto de 0 (es decir, el vacio), se pasan los datos del item seleccionado a los
        'txt auxiliares

        If comboBoxMovimientos.SelectedIndex <> 0 Then
            txtTipoAux.Text = comboBoxMovimientos.SelectedItem
            codigo = Mid(txtTipoAux.Text, 1, 3)
            tipo = Mid(txtTipoAux.Text, 5, Len(txtTipoAux.Text) - 6)
            tipoTipo = Mid(txtTipoAux.Text, Len(txtTipoAux.Text), Len(txtTipoAux.Text))
            'MsgBox("Codigo = /" & codigo & " Tipo = /" & tipo & " TipoTipo = /" & tipoTipo)
            txtCodigoTipoAux.Text = codigo
            txtTipoAux.Text = tipo
            txtTipoTipoAux.Text = tipoTipo
        End If

    End Sub

    Sub pasarDatosArticulo()
        Dim codigo As String
        Dim articulo As String
        Dim precio As String

        'En caso que el index sea distinto de 0 (es decir, el vacio), se pasan los datos del item seleccionado a los
        'txt auxiliares

        If comboBoxArticulo.SelectedIndex <> 0 Then
            txtArticuloAux.Text = comboBoxArticulo.SelectedItem
            codigo = Mid(txtArticuloAux.Text, 1, 3)
            articulo = Mid(txtArticuloAux.Text, 5, Len(txtArticuloAux.Text))
            txtCodigoArticuloAux.Text = codigo
            txtArticuloAux.Text = articulo
            precio = leerPrecioDeArticulo(txtCodigoArticuloAux)
            txtPrecioArticuloAux.Text = precio
        Else
            txtPrecioArticuloAux.Text = ""
        End If

    End Sub

    Sub limpiar()
        comboBoxMovimientos.SelectedIndex = 0
        comboBoxArticulo.SelectedIndex = 0
        txtCantidad.Text = ""
        txtObservacion.Text = ""

        txtCodigoTipoAux.Text = ""
        txtTipoAux.Text = ""
        txtTipoTipoAux.Text = ""
        txtCodigoArticuloAux.Text = ""
        txtArticuloAux.Text = ""
        txtPrecioArticuloAux.Text = ""
    End Sub

    Private Sub comboBoxMovimientos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBoxMovimientos.SelectedIndexChanged
        pasarDatosMovimiento()
        estadoBotones()
    End Sub

    Private Sub comboBoxArticulo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboBoxArticulo.SelectedIndexChanged
        pasarDatosArticulo()
        estadoBotones()
    End Sub

    Private Sub txtCantidad_TextChanged(sender As Object, e As EventArgs) Handles txtCantidad.TextChanged
        soloNumeros(txtCantidad)
        estadoBotones()
    End Sub

    Sub estadoBotones()

        'En caso que no se llenen todos los campos, no se podrá agregar el movimiento

        If comboBoxMovimientos.Text = "" Or comboBoxArticulo.Text = "" Or txtCantidad.Text = "" Then
            btnAgregar.Enabled = False
        Else
            btnAgregar.Enabled = True
        End If
    End Sub

    Private Sub txtObservacion_TextChanged(sender As Object, e As EventArgs) Handles txtObservacion.TextChanged
        cantidadDeCaracteres(txtObservacion, 200)
    End Sub

    Sub setearToolTip()
        toolTip1.SetToolTip(btnLimpiar, "Limpiar")
        toolTip1.SetToolTip(btnAgregar, "Agregar")
        toolTip1.SetToolTip(btnBuscar, "Buscar")
    End Sub
End Class