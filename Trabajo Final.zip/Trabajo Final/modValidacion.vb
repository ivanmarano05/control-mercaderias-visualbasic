﻿Module modValidacion

    Sub cantidadDeCaracteres(txtTexto As TextBox, cantidad As Integer)

        Dim cadena As String

        If Len(txtTexto.Text) > cantidad Then
            cadena = Mid(txtTexto.Text, 1, Len(txtTexto.Text) - 1)
            txtTexto.Text = cadena
        End If

        txtTexto.SelectionStart = txtTexto.Text.Length
    End Sub

    Sub validarPrecio(txtNumero As TextBox, cantidadEnteros As Integer, cantidadDecimales As Integer)
        Dim parte1 As String
        Dim parte2 As String

        parte1 = ""
        parte2 = ""

        If Len(txtNumero.Text) > 1 Then
            parte1 = Mid(txtNumero.Text, 1, Len(txtNumero.Text) - 1)
            parte2 = Mid(txtNumero.Text, Len(txtNumero.Text), 1)
        Else
            parte2 = txtNumero.Text
        End If

        Select Case parte2
            Case "0"
                If parte1.IndexOf("0") = 0 Then

                    If parte1.IndexOf(".") <> 1 Then
                        txtNumero.Text = parte1
                    End If

                End If

                If (txtNumero.Text.Length > cantidadEnteros And txtNumero.Text.IndexOf(".") = -1) Then
                    txtNumero.Text = parte1
                End If

                If txtNumero.Text.IndexOf(".") <> -1 And txtNumero.Text.Length - txtNumero.Text.IndexOf(".") - 1 > cantidadDecimales Then
                    txtNumero.Text = parte1
                End If

            Case "1" To "9"
                If parte1.IndexOf("0") = 0 And parte1.IndexOf(".") <> 1 Then
                    txtNumero.Text = parte2
                End If

                If (txtNumero.Text.Length > cantidadEnteros And txtNumero.Text.IndexOf(".") = -1) Then
                    txtNumero.Text = parte1
                End If

                If txtNumero.Text.IndexOf(".") <> -1 And txtNumero.Text.Length - txtNumero.Text.IndexOf(".") - 1 > cantidadDecimales Then
                    txtNumero.Text = parte1
                End If

            Case ",", "."
                If parte1.IndexOf(".") = -1 Then
                    txtNumero.Text = parte1 & "."
                Else
                    txtNumero.Text = parte1
                End If

            Case Else
                txtNumero.Text = parte1
        End Select

        txtNumero.SelectionStart = txtNumero.Text.Length
    End Sub

    Sub soloNumeros(txtCampo As TextBox)
        txtCampo.SelectionStart = txtCampo.Text.Length

        Dim parteSoloNumeros As String
        Dim numeroDesde As Char
        Dim numeroHasta As Char

        numeroDesde = Chr(48)
        numeroHasta = Chr(57)

        For I = 1 To Len(txtCampo.Text)
            Select Case txtCampo.Text(I - 1)
                Case numeroDesde To numeroHasta
                    Exit Select
                Case Else
                    parteSoloNumeros = Mid(txtCampo.Text, 1, Len(txtCampo.Text) - 1)
                    txtCampo.Text = parteSoloNumeros
            End Select
        Next
    End Sub

End Module
