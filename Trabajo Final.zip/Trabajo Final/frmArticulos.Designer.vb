﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmArticulos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmArticulos))
        Me.lblNombre = New System.Windows.Forms.Label()
        Me.lblAgrupacion = New System.Windows.Forms.Label()
        Me.lblPrecio = New System.Windows.Forms.Label()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.txtPrecio = New System.Windows.Forms.TextBox()
        Me.comboBoxAgrupaciones = New System.Windows.Forms.ComboBox()
        Me.txtAgrupacionAux = New System.Windows.Forms.TextBox()
        Me.btnAgregar = New System.Windows.Forms.Button()
        Me.txtCodigoAgrupacionAux = New System.Windows.Forms.TextBox()
        Me.txtCodigo = New System.Windows.Forms.TextBox()
        Me.lblCodigo = New System.Windows.Forms.Label()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblNombre.Location = New System.Drawing.Point(94, 63)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(100, 25)
        Me.lblNombre.TabIndex = 0
        Me.lblNombre.Text = "Nombre:"
        '
        'lblAgrupacion
        '
        Me.lblAgrupacion.AutoSize = True
        Me.lblAgrupacion.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblAgrupacion.Location = New System.Drawing.Point(59, 97)
        Me.lblAgrupacion.Name = "lblAgrupacion"
        Me.lblAgrupacion.Size = New System.Drawing.Size(134, 25)
        Me.lblAgrupacion.TabIndex = 1
        Me.lblAgrupacion.Text = "Agrupación:"
        '
        'lblPrecio
        '
        Me.lblPrecio.AutoSize = True
        Me.lblPrecio.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblPrecio.Location = New System.Drawing.Point(111, 134)
        Me.lblPrecio.Name = "lblPrecio"
        Me.lblPrecio.Size = New System.Drawing.Size(82, 25)
        Me.lblPrecio.TabIndex = 2
        Me.lblPrecio.Text = "Precio:"
        '
        'txtNombre
        '
        Me.txtNombre.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtNombre.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtNombre.Location = New System.Drawing.Point(200, 63)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(207, 29)
        Me.txtNombre.TabIndex = 3
        '
        'txtPrecio
        '
        Me.txtPrecio.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtPrecio.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtPrecio.Location = New System.Drawing.Point(200, 135)
        Me.txtPrecio.Name = "txtPrecio"
        Me.txtPrecio.Size = New System.Drawing.Size(125, 29)
        Me.txtPrecio.TabIndex = 5
        Me.txtPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'comboBoxAgrupaciones
        '
        Me.comboBoxAgrupaciones.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.comboBoxAgrupaciones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxAgrupaciones.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.comboBoxAgrupaciones.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.comboBoxAgrupaciones.FormattingEnabled = True
        Me.comboBoxAgrupaciones.Location = New System.Drawing.Point(199, 98)
        Me.comboBoxAgrupaciones.Name = "comboBoxAgrupaciones"
        Me.comboBoxAgrupaciones.Size = New System.Drawing.Size(208, 28)
        Me.comboBoxAgrupaciones.TabIndex = 6
        '
        'txtAgrupacionAux
        '
        Me.txtAgrupacionAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtAgrupacionAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtAgrupacionAux.Location = New System.Drawing.Point(10, 160)
        Me.txtAgrupacionAux.Name = "txtAgrupacionAux"
        Me.txtAgrupacionAux.Size = New System.Drawing.Size(100, 29)
        Me.txtAgrupacionAux.TabIndex = 7
        '
        'btnAgregar
        '
        Me.btnAgregar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAgregar.Image = CType(resources.GetObject("btnAgregar.Image"), System.Drawing.Image)
        Me.btnAgregar.Location = New System.Drawing.Point(119, 191)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(75, 50)
        Me.btnAgregar.TabIndex = 8
        Me.btnAgregar.UseVisualStyleBackColor = False
        '
        'txtCodigoAgrupacionAux
        '
        Me.txtCodigoAgrupacionAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCodigoAgrupacionAux.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtCodigoAgrupacionAux.Location = New System.Drawing.Point(36, 125)
        Me.txtCodigoAgrupacionAux.Name = "txtCodigoAgrupacionAux"
        Me.txtCodigoAgrupacionAux.Size = New System.Drawing.Size(44, 29)
        Me.txtCodigoAgrupacionAux.TabIndex = 9
        '
        'txtCodigo
        '
        Me.txtCodigo.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCodigo.Font = New System.Drawing.Font("Verdana", 13.0!)
        Me.txtCodigo.Location = New System.Drawing.Point(200, 27)
        Me.txtCodigo.Name = "txtCodigo"
        Me.txtCodigo.ReadOnly = True
        Me.txtCodigo.Size = New System.Drawing.Size(50, 29)
        Me.txtCodigo.TabIndex = 13
        '
        'lblCodigo
        '
        Me.lblCodigo.AutoSize = True
        Me.lblCodigo.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblCodigo.Location = New System.Drawing.Point(105, 30)
        Me.lblCodigo.Name = "lblCodigo"
        Me.lblCodigo.Size = New System.Drawing.Size(89, 25)
        Me.lblCodigo.TabIndex = 12
        Me.lblCodigo.Text = "Código:"
        '
        'btnModificar
        '
        Me.btnModificar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnModificar.Image = CType(resources.GetObject("btnModificar.Image"), System.Drawing.Image)
        Me.btnModificar.Location = New System.Drawing.Point(200, 191)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(75, 50)
        Me.btnModificar.TabIndex = 14
        Me.btnModificar.UseVisualStyleBackColor = False
        '
        'btnEliminar
        '
        Me.btnEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnEliminar.Image = CType(resources.GetObject("btnEliminar.Image"), System.Drawing.Image)
        Me.btnEliminar.Location = New System.Drawing.Point(281, 191)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(75, 50)
        Me.btnEliminar.TabIndex = 15
        Me.btnEliminar.UseVisualStyleBackColor = False
        '
        'btnBuscar
        '
        Me.btnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBuscar.Image = CType(resources.GetObject("btnBuscar.Image"), System.Drawing.Image)
        Me.btnBuscar.Location = New System.Drawing.Point(362, 191)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(75, 50)
        Me.btnBuscar.TabIndex = 16
        Me.btnBuscar.UseVisualStyleBackColor = False
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLimpiar.Image = CType(resources.GetObject("btnLimpiar.Image"), System.Drawing.Image)
        Me.btnLimpiar.Location = New System.Drawing.Point(36, 191)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(75, 50)
        Me.btnLimpiar.TabIndex = 17
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'frmArticulos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(462, 255)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.btnEliminar)
        Me.Controls.Add(Me.btnModificar)
        Me.Controls.Add(Me.txtCodigo)
        Me.Controls.Add(Me.lblCodigo)
        Me.Controls.Add(Me.txtCodigoAgrupacionAux)
        Me.Controls.Add(Me.btnAgregar)
        Me.Controls.Add(Me.txtAgrupacionAux)
        Me.Controls.Add(Me.comboBoxAgrupaciones)
        Me.Controls.Add(Me.txtPrecio)
        Me.Controls.Add(Me.txtNombre)
        Me.Controls.Add(Me.lblPrecio)
        Me.Controls.Add(Me.lblAgrupacion)
        Me.Controls.Add(Me.lblNombre)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(478, 294)
        Me.MinimumSize = New System.Drawing.Size(478, 294)
        Me.Name = "frmArticulos"
        Me.Text = "Articulos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNombre As Label
    Friend WithEvents lblAgrupacion As Label
    Friend WithEvents lblPrecio As Label
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtPrecio As TextBox
    Friend WithEvents comboBoxAgrupaciones As ComboBox
    Friend WithEvents txtAgrupacionAux As TextBox
    Friend WithEvents btnAgregar As Button
    Friend WithEvents txtCodigoAgrupacionAux As TextBox
    Friend WithEvents txtCodigo As TextBox
    Friend WithEvents lblCodigo As Label
    Friend WithEvents btnModificar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents toolTip1 As ToolTip
End Class
