﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusquedaMovimientosDeCantidades
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBusquedaMovimientosDeCantidades))
        Me.txtAux = New System.Windows.Forms.TextBox()
        Me.listMovimientosDeCantidades = New System.Windows.Forms.ListBox()
        Me.listAux = New System.Windows.Forms.ListBox()
        Me.txtBusqueda = New System.Windows.Forms.TextBox()
        Me.btnObservacion = New System.Windows.Forms.Button()
        Me.txtCodigoAux = New System.Windows.Forms.TextBox()
        Me.lblCodigo = New System.Windows.Forms.Label()
        Me.lblMovimiento = New System.Windows.Forms.Label()
        Me.lblArticulo = New System.Windows.Forms.Label()
        Me.lblFecha = New System.Windows.Forms.Label()
        Me.lblCantidad = New System.Windows.Forms.Label()
        Me.lblPrecio = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtAux
        '
        Me.txtAux.Location = New System.Drawing.Point(364, 382)
        Me.txtAux.Name = "txtAux"
        Me.txtAux.Size = New System.Drawing.Size(316, 20)
        Me.txtAux.TabIndex = 7
        '
        'listMovimientosDeCantidades
        '
        Me.listMovimientosDeCantidades.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.listMovimientosDeCantidades.Font = New System.Drawing.Font("Courier New", 13.0!)
        Me.listMovimientosDeCantidades.FormattingEnabled = True
        Me.listMovimientosDeCantidades.ItemHeight = 20
        Me.listMovimientosDeCantidades.Location = New System.Drawing.Point(12, 104)
        Me.listMovimientosDeCantidades.Name = "listMovimientosDeCantidades"
        Me.listMovimientosDeCantidades.Size = New System.Drawing.Size(678, 304)
        Me.listMovimientosDeCantidades.TabIndex = 6
        '
        'listAux
        '
        Me.listAux.Font = New System.Drawing.Font("Courier New", 9.75!)
        Me.listAux.FormattingEnabled = True
        Me.listAux.ItemHeight = 16
        Me.listAux.Location = New System.Drawing.Point(15, 433)
        Me.listAux.Name = "listAux"
        Me.listAux.Size = New System.Drawing.Size(530, 164)
        Me.listAux.TabIndex = 8
        '
        'txtBusqueda
        '
        Me.txtBusqueda.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtBusqueda.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.txtBusqueda.Location = New System.Drawing.Point(247, 37)
        Me.txtBusqueda.Name = "txtBusqueda"
        Me.txtBusqueda.Size = New System.Drawing.Size(192, 25)
        Me.txtBusqueda.TabIndex = 9
        '
        'btnObservacion
        '
        Me.btnObservacion.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.btnObservacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnObservacion.Location = New System.Drawing.Point(492, 26)
        Me.btnObservacion.Name = "btnObservacion"
        Me.btnObservacion.Size = New System.Drawing.Size(97, 43)
        Me.btnObservacion.TabIndex = 10
        Me.btnObservacion.Text = "Ver Observacion"
        Me.btnObservacion.UseVisualStyleBackColor = False
        '
        'txtCodigoAux
        '
        Me.txtCodigoAux.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtCodigoAux.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.txtCodigoAux.Location = New System.Drawing.Point(91, 37)
        Me.txtCodigoAux.Name = "txtCodigoAux"
        Me.txtCodigoAux.Size = New System.Drawing.Size(100, 25)
        Me.txtCodigoAux.TabIndex = 11
        '
        'lblCodigo
        '
        Me.lblCodigo.AutoSize = True
        Me.lblCodigo.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblCodigo.Location = New System.Drawing.Point(9, 87)
        Me.lblCodigo.Name = "lblCodigo"
        Me.lblCodigo.Size = New System.Drawing.Size(51, 14)
        Me.lblCodigo.TabIndex = 12
        Me.lblCodigo.Text = "Código"
        '
        'lblMovimiento
        '
        Me.lblMovimiento.AutoSize = True
        Me.lblMovimiento.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblMovimiento.Location = New System.Drawing.Point(66, 87)
        Me.lblMovimiento.Name = "lblMovimiento"
        Me.lblMovimiento.Size = New System.Drawing.Size(78, 14)
        Me.lblMovimiento.TabIndex = 13
        Me.lblMovimiento.Text = "Movimiento"
        '
        'lblArticulo
        '
        Me.lblArticulo.AutoSize = True
        Me.lblArticulo.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblArticulo.Location = New System.Drawing.Point(234, 87)
        Me.lblArticulo.Name = "lblArticulo"
        Me.lblArticulo.Size = New System.Drawing.Size(53, 14)
        Me.lblArticulo.TabIndex = 14
        Me.lblArticulo.Text = "Artículo"
        '
        'lblFecha
        '
        Me.lblFecha.AutoSize = True
        Me.lblFecha.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblFecha.Location = New System.Drawing.Point(383, 87)
        Me.lblFecha.Name = "lblFecha"
        Me.lblFecha.Size = New System.Drawing.Size(44, 14)
        Me.lblFecha.TabIndex = 15
        Me.lblFecha.Text = "Fecha"
        '
        'lblCantidad
        '
        Me.lblCantidad.AutoSize = True
        Me.lblCantidad.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblCantidad.Location = New System.Drawing.Point(486, 87)
        Me.lblCantidad.Name = "lblCantidad"
        Me.lblCantidad.Size = New System.Drawing.Size(64, 14)
        Me.lblCantidad.TabIndex = 16
        Me.lblCantidad.Text = "Cantidad"
        '
        'lblPrecio
        '
        Me.lblPrecio.AutoSize = True
        Me.lblPrecio.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.lblPrecio.Location = New System.Drawing.Point(575, 87)
        Me.lblPrecio.Name = "lblPrecio"
        Me.lblPrecio.Size = New System.Drawing.Size(45, 14)
        Me.lblPrecio.TabIndex = 17
        Me.lblPrecio.Text = "Precio"
        '
        'frmBusquedaMovimientosDeCantidades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(702, 414)
        Me.Controls.Add(Me.lblPrecio)
        Me.Controls.Add(Me.lblCantidad)
        Me.Controls.Add(Me.lblFecha)
        Me.Controls.Add(Me.lblArticulo)
        Me.Controls.Add(Me.lblMovimiento)
        Me.Controls.Add(Me.lblCodigo)
        Me.Controls.Add(Me.txtCodigoAux)
        Me.Controls.Add(Me.btnObservacion)
        Me.Controls.Add(Me.txtBusqueda)
        Me.Controls.Add(Me.listAux)
        Me.Controls.Add(Me.txtAux)
        Me.Controls.Add(Me.listMovimientosDeCantidades)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(718, 453)
        Me.MinimumSize = New System.Drawing.Size(718, 453)
        Me.Name = "frmBusquedaMovimientosDeCantidades"
        Me.Text = "Busqueda Movimientos De Cantidades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtAux As TextBox
    Friend WithEvents listMovimientosDeCantidades As ListBox
    Friend WithEvents listAux As ListBox
    Friend WithEvents txtBusqueda As TextBox
    Friend WithEvents btnObservacion As Button
    Friend WithEvents txtCodigoAux As TextBox
    Friend WithEvents lblCodigo As Label
    Friend WithEvents lblMovimiento As Label
    Friend WithEvents lblArticulo As Label
    Friend WithEvents lblFecha As Label
    Friend WithEvents lblCantidad As Label
    Friend WithEvents lblPrecio As Label
End Class
